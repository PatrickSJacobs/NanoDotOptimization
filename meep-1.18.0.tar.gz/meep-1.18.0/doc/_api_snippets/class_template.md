---
<a id="{class_name}"></a>

### {class_name}

```python
class {class_name}({base_classes}):
```

<div class="class_docstring" markdown="1">

{docstring}

</div>

