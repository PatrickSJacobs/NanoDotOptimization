
<a id="{function_name}"></a>

```python
def {function_name}{parameters}:{other_signatures}
```

<div class="function_docstring" markdown="1">

{docstring}

</div>