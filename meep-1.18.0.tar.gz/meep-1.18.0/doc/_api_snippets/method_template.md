
<a id="{class_name}.{method_name}"></a>

<div class="class_members" markdown="1">

```python
def {method_name}{parameters}:{other_signatures}
```

<div class="method_docstring" markdown="1">

{docstring}

</div>

</div>