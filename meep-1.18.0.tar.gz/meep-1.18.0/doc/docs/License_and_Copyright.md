---
# License and Copyright
---

Meep is copyright © 2005–2021, Massachusetts Institute of Technology.

Meep is free software. You can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or at your option any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this library; if not, write to the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA. You can also find it on the [GNU homepage](http://www.gnu.org/copyleft/gpl.html).

As a clarification, we should note that Python and Scheme control files, written by the user which do not contain code distributed with Meep and loaded at runtime by the Meep software, are *not* derived works of Meep and do *not* fall thereby under the restrictions of the GNU General Public License. On the other hand, C++ programs linked with the Meep libraries *are* derived works, and you must obey the terms of the GPL if you wish to distribute programs based in part on Meep. You are not affected for programs you do not distribute.
